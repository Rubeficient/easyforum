import { useCallback, useEffect, useRef, useState } from "react";
import { api, timeAgo, type AdminTag, type DiscussionRow, type Me, type Post, type ReactionType, type Revision, type Tag, type Thread } from "./api";

// ---- tiny path router (real URLs so server rendering can be added later)
type Route = { kind: "list"; tag?: string } | { kind: "thread"; id: number } | { kind: "admin" };
const parse = (p: string): Route => {
  if (p.startsWith("/admin")) return { kind: "admin" };
  const d = p.match(/^\/d\/(\d+)/);
  if (d) return { kind: "thread", id: Number(d[1]) };
  const t = p.match(/^\/t\/([\w-]+)/);
  return t ? { kind: "list", tag: t[1] } : { kind: "list" };
};
function useRoute() {
  const [route, setRoute] = useState<Route>(() => parse(location.pathname));
  useEffect(() => {
    const on = () => setRoute(parse(location.pathname));
    addEventListener("popstate", on);
    return () => removeEventListener("popstate", on);
  }, []);
  const go = useCallback((path: string) => {
    history.pushState(null, "", path);
    setRoute(parse(path));
    scrollTo(0, 0);
  }, []);
  return [route, go] as const;
}

type ComposerState =
  | null
  | { mode: "new" }
  | { mode: "reply"; discussionId: number; text: string }
  | { mode: "edit"; postId: number; text: string };

export default function App() {
  const [route, go] = useRoute();
  const [me, setMe] = useState<Me>(null);
  const [tags, setTags] = useState<Tag[]>([]);
  const [reactions, setReactions] = useState<ReactionType[]>([]);
  const [showAuth, setShowAuth] = useState<null | "login" | "register">(null);
  const [composer, setComposer] = useState<ComposerState>(null);
  const [version, setVersion] = useState(0); // bump to reload data
  const reload = () => setVersion((v) => v + 1);

  useEffect(() => {
    api<Me>("/me").then(setMe).catch(() => {});
    api<Tag[]>("/tags").then(setTags).catch(() => {});
    api<ReactionType[]>("/reaction-types").then(setReactions).catch(() => {});
  }, []);

  const requireLogin = (fn: () => void) => (me ? fn() : setShowAuth("login"));
  const activeTag = route.kind === "list" ? route.tag : undefined;

  return (
    <>
      <header className="top">
        <a className="brand" href="/" onClick={(e) => { e.preventDefault(); go("/"); }}>Forum</a>
        <div className="grow" />
        {me ? (
          <>
            <span className="who">{me.username}</span>
            <button className="btn ghost" onClick={async () => { await api("/logout", "POST"); setMe(null); }}>Log out</button>
          </>
        ) : (
          <>
            <button className="btn ghost" onClick={() => setShowAuth("login")}>Log in</button>
            <button className="btn" onClick={() => setShowAuth("register")}>Sign up</button>
          </>
        )}
      </header>

      <div className="shell">
        <nav className="side">
          {(!me || tags.some((t) => t.can_start)) && <button className="btn wide" onClick={() => requireLogin(() => setComposer({ mode: "new" }))}>Start a discussion</button>}
          <ul>
            <li><a className={route.kind === "list" && !activeTag ? "on" : ""} href="/" onClick={(e) => { e.preventDefault(); go("/"); }}>All discussions</a></li>
            {tags.map((t) => (
              <li key={t.id}>
                <a className={activeTag === t.slug ? "on" : ""} href={`/t/${t.slug}`} onClick={(e) => { e.preventDefault(); go(`/t/${t.slug}`); }}>
                  <i className="dot" style={{ background: t.color }} />{t.name}
                </a>
              </li>
            ))}
            {me?.group_id === 1 && <li><a className={route.kind === "admin" ? "on" : ""} href="/admin" onClick={(e) => { e.preventDefault(); go("/admin"); }}>Admin</a></li>}
          </ul>
        </nav>

        <main className="main">
          {route.kind === "admin" ? (me?.group_id === 1 ? <AdminView onChange={() => api<Tag[]>("/tags").then(setTags)} /> : <p className="muted">Only admins can open this page.</p>)
            : route.kind === "list"
            ? <DiscussionList tag={route.tag} go={go} version={version} />
            : <ThreadView id={route.id} me={me} reactions={reactions} version={version} setComposer={setComposer} requireLogin={requireLogin} reload={reload} />}
        </main>
      </div>

      {showAuth && <AuthDialog mode={showAuth} setMode={setShowAuth} onDone={(u) => { setMe(u); setShowAuth(null); }} />}
      {composer && <Composer state={composer} tags={tags.filter((t) => t.can_start)} onClose={() => setComposer(null)} onDone={(newId) => { setComposer(null); if (newId) go(`/d/${newId}`); reload(); }} />}
    </>
  );
}

function DiscussionList({ tag, go, version }: { tag?: string; go: (p: string) => void; version: number }) {
  const [rows, setRows] = useState<DiscussionRow[] | null>(null);
  useEffect(() => {
    setRows(null);
    api<DiscussionRow[]>(`/discussions${tag ? `?tag=${tag}` : ""}`).then(setRows).catch(() => setRows([]));
  }, [tag, version]);
  if (!rows) return <p className="muted">Loading discussions…</p>;
  if (!rows.length) return <p className="muted">No discussions here yet. Start the first one.</p>;
  return (
    <ul className="list">
      {rows.map((d) => (
        <li key={d.id}>
          <a href={`/d/${d.id}`} onClick={(e) => { e.preventDefault(); go(`/d/${d.id}`); }}>
            <span className="avatar">{d.author[0].toUpperCase()}</span>
            <span className="row-main">
              <span className="row-title">
                {d.pinned ? <b className="flag">Pinned</b> : null}{d.locked ? <b className="flag">Locked</b> : null}{d.title}
              </span>
              <span className="muted small">{d.author} · active {timeAgo(d.last_post_at)}</span>
            </span>
            <span className="chip" style={{ background: d.tag_color }}>{d.tag_name}</span>
            <span className="count" title="Posts">{d.post_count}</span>
          </a>
        </li>
      ))}
    </ul>
  );
}

function ThreadView(p: {
  id: number; me: Me; reactions: ReactionType[]; version: number;
  setComposer: (c: ComposerState) => void; requireLogin: (fn: () => void) => void; reload: () => void;
}) {
  const [data, setData] = useState<Thread | null>(null);
  const [err, setErr] = useState("");
  const [history, setHistory] = useState<number | null>(null);
  useEffect(() => {
    api<Thread>(`/discussions/${p.id}`).then(setData).catch((e) => setErr(e.message));
  }, [p.id, p.version, p.me?.id]);
  if (err) return <p className="error">{err}</p>;
  if (!data) return <p className="muted">Loading discussion…</p>;
  const { discussion: d, posts } = data;
  const staff = p.me && (p.me.group_id === 1 || p.me.group_id === 2);

  const react = async (post: Post, reactionId: number) => {
    if (!p.me) return p.requireLogin(() => {});
    await api(`/posts/${post.id}/react`, "POST", { reactionId });
    p.reload();
  };

  return (
    <article>
      <div className="thread-head">
        <span className="chip" style={{ background: d.tag_color }}>{d.tag_name}</span>
        <h1>{d.title}</h1>
        {staff && (
          <div className="mod">
            <button className="btn ghost" onClick={async () => { await api(`/discussions/${d.id}`, "PATCH", { pinned: !d.pinned }); p.reload(); }}>{d.pinned ? "Unpin" : "Pin"}</button>
            <button className="btn ghost" onClick={async () => { await api(`/discussions/${d.id}`, "PATCH", { locked: !d.locked }); p.reload(); }}>{d.locked ? "Unlock" : "Lock"}</button>
          </div>
        )}
      </div>

      {posts.map((post) => (
        <section className="post" key={post.id}>
          <span className="avatar big">{post.author[0].toUpperCase()}</span>
          <div className="post-body">
            <div className="post-meta"><b>{post.author}</b> <span className="muted small">{timeAgo(post.created_at)}{post.edited_at ? ` · edited ${timeAgo(post.edited_at)}` : ""}</span>{post.edited_at && p.me && (p.me.id === post.user_id || staff) ? <> <button className="link small" onClick={() => setHistory(post.id)}>Edit history</button></> : null}</div>
            {/* html is produced by the server's whitelist BBCode renderer (input escaped first) */}
            <div className="content" dangerouslySetInnerHTML={{ __html: post.html }} />
            <div className="post-foot">
              <div className="reacts">
                {p.reactions.map((r) => {
                  const n = post.reactions.find((x) => x.reaction_id === r.id)?.n ?? 0;
                  return (
                    <button key={r.id} className={`react${post.my_reaction === r.id ? " mine" : ""}`} title={r.label} aria-label={r.label} onClick={() => react(post, r.id)}>
                      {r.emoji}{n > 0 && <span>{n}</span>}
                    </button>
                  );
                })}
              </div>
              <div className="acts">
                {(!p.me || data.can_reply) && <button className="link" onClick={() => p.requireLogin(() => p.setComposer({ mode: "reply", discussionId: d.id, text: `[quote=${post.author}]${post.content}[/quote]\n` }))}>Quote</button>}
                {p.me && (p.me.id === post.user_id || staff) && <button className="link" onClick={() => p.setComposer({ mode: "edit", postId: post.id, text: post.content })}>Edit</button>}
              </div>
            </div>
          </div>
        </section>
      ))}

      {!p.me || data.can_reply
        ? <button className="btn" onClick={() => p.requireLogin(() => p.setComposer({ mode: "reply", discussionId: d.id, text: "" }))}>Reply</button>
        : <p className="muted">{d.locked ? "This discussion is locked." : "You don't have permission to reply in this tag."}</p>}
      {history && <RevisionsDialog postId={history} onClose={() => setHistory(null)} />}
    </article>
  );
}

function Composer({ state, tags, onClose, onDone }: { state: NonNullable<ComposerState>; tags: Tag[]; onClose: () => void; onDone: (newId?: number) => void }) {
  const [title, setTitle] = useState("");
  const [tagId, setTagId] = useState<number>(tags[0]?.id ?? 0);
  const [text, setText] = useState(state.mode === "new" ? "" : state.text);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const ta = useRef<HTMLTextAreaElement>(null);

  const wrap = (open: string, close: string) => {
    const el = ta.current!;
    const [a, b] = [el.selectionStart, el.selectionEnd];
    setText(text.slice(0, a) + open + text.slice(a, b) + close + text.slice(b));
    setTimeout(() => { el.focus(); el.setSelectionRange(a + open.length, b + open.length); });
  };

  const submit = async () => {
    setBusy(true); setErr("");
    try {
      if (state.mode === "new") onDone((await api<{ id: number }>("/discussions", "POST", { title, tagId, content: text })).id);
      else if (state.mode === "reply") { await api(`/discussions/${state.discussionId}/posts`, "POST", { content: text }); onDone(); }
      else { await api(`/posts/${state.postId}`, "PUT", { content: text }); onDone(); }
    } catch (e: any) { setErr(e.message); setBusy(false); }
  };

  const heading = state.mode === "new" ? "Start a discussion" : state.mode === "reply" ? "Reply" : "Edit post";
  return (
    <div className="composer" role="dialog" aria-label={heading}>
      <div className="composer-head"><b>{heading}</b><button className="link" onClick={onClose}>Discard</button></div>
      {state.mode === "new" && (
        <div className="row">
          <input placeholder="Discussion title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
          <select value={tagId} onChange={(e) => setTagId(Number(e.target.value))} aria-label="Tag">
            {tags.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>
      )}
      <div className="toolbar">
        <button type="button" onClick={() => wrap("[b]", "[/b]")}><b>B</b></button>
        <button type="button" onClick={() => wrap("[i]", "[/i]")}><i>I</i></button>
        <button type="button" onClick={() => wrap("[quote]", "[/quote]")}>Quote</button>
        <button type="button" onClick={() => wrap("[code]", "[/code]")}>Code</button>
        <button type="button" onClick={() => wrap("[spoiler]", "[/spoiler]")}>Spoiler</button>
        <button type="button" onClick={() => wrap("[url=https://]", "[/url]")}>Link</button>
      </div>
      <textarea ref={ta} value={text} onChange={(e) => setText(e.target.value)} placeholder="Write your post. BBCode works here." rows={8} autoFocus />
      {err && <p className="error">{err}</p>}
      <div className="composer-foot"><button className="btn" disabled={busy} onClick={submit}>{state.mode === "edit" ? "Save changes" : "Post"}</button></div>
    </div>
  );
}

function AuthDialog({ mode, setMode, onDone }: { mode: "login" | "register"; setMode: (m: "login" | "register") => void; onDone: (u: Me) => void }) {
  const [f, setF] = useState({ username: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr("");
    try { onDone(await api<Me>(mode === "login" ? "/login" : "/register", "POST", f)); }
    catch (x: any) { setErr(x.message); }
  };
  return (
    <div className="backdrop" onMouseDown={(e) => e.target === e.currentTarget && onDone(null)}>
      <form className="dialog" onSubmit={submit}>
        <h2>{mode === "login" ? "Log in" : "Create an account"}</h2>
        <input placeholder="Username" value={f.username} onChange={set("username")} autoFocus autoComplete="username" />
        {mode === "register" && <input placeholder="Email" type="email" value={f.email} onChange={set("email")} autoComplete="email" />}
        <input placeholder="Password" type="password" value={f.password} onChange={set("password")} autoComplete={mode === "login" ? "current-password" : "new-password"} />
        {err && <p className="error">{err}</p>}
        <button className="btn wide">{mode === "login" ? "Log in" : "Sign up"}</button>
        <button type="button" className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "Need an account? Sign up" : "Already registered? Log in"}
        </button>
      </form>
    </div>
  );
}

function RevisionsDialog({ postId, onClose }: { postId: number; onClose: () => void }) {
  const [rows, setRows] = useState<Revision[] | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => { api<Revision[]>(`/posts/${postId}/revisions`).then(setRows).catch((e) => setErr(e.message)); }, [postId]);
  return (
    <div className="backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog wide-dialog" role="dialog" aria-label="Edit history">
        <h2>Edit history</h2>
        {err && <p className="error">{err}</p>}
        {!rows && !err && <p className="muted">Loading…</p>}
        {rows?.length === 0 && <p className="muted">No earlier versions.</p>}
        {rows?.map((r) => (
          <div key={r.id} className="rev">
            <div className="muted small">Replaced by {r.editor} {timeAgo(r.created_at)}</div>
            <pre>{r.content}</pre>
          </div>
        ))}
        <button className="btn" onClick={onClose}>Close</button>
      </div>
    </div>
  );
}

const PERMS: { key: string; label: string }[] = [
  { key: "view", label: "View" }, { key: "start", label: "Start discussions" }, { key: "reply", label: "Reply" },
];

function AdminView({ onChange }: { onChange: () => void }) {
  const [tags, setTags] = useState<AdminTag[] | null>(null);
  const [msg, setMsg] = useState("");
  const [fresh, setFresh] = useState({ name: "", color: "#2f6f8f" });
  const load = () => api<AdminTag[]>("/admin/tags").then(setTags).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, []);

  const toggle = (t: AdminTag, group: string, perm: string) => {
    const cur = t.perms[group] ?? [];
    const next = cur.includes(perm) ? cur.filter((x) => x !== perm) : [...cur, perm];
    setTags(tags!.map((x) => (x.id === t.id ? { ...x, perms: { ...x.perms, [group]: next } } : x)));
  };
  const save = async (t: AdminTag) => {
    try { await api(`/admin/tags/${t.id}`, "PUT", { name: t.name, color: t.color, perms: t.perms }); setMsg(`Saved ${t.name}.`); onChange(); await load(); }
    catch (e: any) { setMsg(e.message); }
  };
  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    try { await api("/admin/tags", "POST", fresh); setFresh({ ...fresh, name: "" }); setMsg("Tag created."); onChange(); await load(); }
    catch (x: any) { setMsg(x.message); }
  };

  if (!tags) return <p className="muted">{msg || "Loading tags…"}</p>;
  return (
    <section>
      <h1>Tags and permissions</h1>
      <p className="muted">Admins and moderators can always do everything. These settings apply to members and guests. Guests can only be allowed to view.</p>
      {msg && <p className="notice" role="status">{msg}</p>}
      {tags.map((t) => (
        <div className="admin-tag" key={t.id}>
          <div className="admin-tag-head">
            <input type="color" value={t.color} aria-label="Tag color" onChange={(e) => setTags(tags.map((x) => (x.id === t.id ? { ...x, color: e.target.value } : x)))} />
            <input value={t.name} aria-label="Tag name" maxLength={30} onChange={(e) => setTags(tags.map((x) => (x.id === t.id ? { ...x, name: e.target.value } : x)))} />
            <button className="btn" onClick={() => save(t)}>Save changes</button>
          </div>
          <table className="perm-table">
            <thead><tr><th></th>{PERMS.map((p) => <th key={p.key}>{p.label}</th>)}</tr></thead>
            <tbody>
              {[["3", "Members"], ["4", "Guests"]].map(([g, label]) => (
                <tr key={g}>
                  <th scope="row">{label}</th>
                  {PERMS.map((p) => (
                    <td key={p.key}>
                      {g === "4" && p.key !== "view" ? <span className="muted">–</span> : (
                        <input type="checkbox" aria-label={`${label}: ${p.label}`} checked={(t.perms[g] ?? []).includes(p.key)} onChange={() => toggle(t, g, p.key)} />
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
      <form className="admin-tag" onSubmit={add}>
        <div className="admin-tag-head">
          <input type="color" value={fresh.color} aria-label="New tag color" onChange={(e) => setFresh({ ...fresh, color: e.target.value })} />
          <input placeholder="New tag name" value={fresh.name} maxLength={30} onChange={(e) => setFresh({ ...fresh, name: e.target.value })} />
          <button className="btn" disabled={!fresh.name.trim()}>Add tag</button>
        </div>
      </form>
    </section>
  );
}
