export type Me = { id: number; username: string; group_id: number } | null;
export type Tag = { id: number; name: string; slug: string; color: string; can_start: boolean };
export type AdminTag = { id: number; name: string; slug: string; color: string; perms: Record<string, string[]> };
export type Revision = { id: number; content: string; created_at: number; editor: string };
export type ReactionType = { id: number; key: string; emoji: string; label: string };
export type DiscussionRow = {
  id: number; title: string; pinned: number; locked: number; post_count: number;
  last_post_at: number; author: string; tag_name: string; tag_color: string; tag_slug: string;
};
export type Post = {
  id: number; html: string; content: string; created_at: number; edited_at: number | null;
  user_id: number; author: string; reactions: { reaction_id: number; n: number }[]; my_reaction: number | null;
};
export type Thread = {
  discussion: { id: number; title: string; pinned: number; locked: number; tag_name: string; tag_color: string };
  posts: Post[];
  can_reply: boolean;
};

export async function api<T = any>(path: string, method = "GET", body?: unknown): Promise<T> {
  const r = await fetch("/api" + path, {
    method,
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((data as any).error ?? "Something went wrong. Try again.");
  return data as T;
}

export function timeAgo(ms: number) {
  const s = Math.max(1, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
