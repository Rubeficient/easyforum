export type User = { id: number; username: string; group_id: number };
export type AppEnv = {
  Bindings: { DB: D1Database; ASSETS: Fetcher; SITE_NAME?: string };
  Variables: { user: User | null };
};
export type Perm = "view" | "start" | "reply";

export const ADMIN = 1;
export const MOD = 2;
export const MEMBER = 3;
export const GUEST = 4;

export const groupOf = (u: User | null) => (u ? u.group_id : GUEST);
export const isStaff = (u: User | null) => !!u && (u.group_id === ADMIN || u.group_id === MOD);
export const isAdmin = (u: User | null) => !!u && u.group_id === ADMIN;

/** SQL fragment limiting a query to tags the user may view (staff see everything). */
export function visibleSql(u: User | null, col: string): { sql: string; binds: number[] } {
  if (isStaff(u)) return { sql: "1=1", binds: [] };
  return {
    sql: `${col} IN (SELECT tag_id FROM tag_permissions WHERE group_id = ? AND permission = 'view')`,
    binds: [groupOf(u)],
  };
}

export async function can(db: D1Database, u: User | null, tagId: number, perm: Perm): Promise<boolean> {
  if (isStaff(u)) return true;
  const row = await db
    .prepare("SELECT 1 FROM tag_permissions WHERE tag_id = ? AND group_id = ? AND permission = ?")
    .bind(tagId, groupOf(u), perm)
    .first();
  return !!row;
}
