// Whitelist BBCode renderer. Input is HTML-escaped FIRST, so the only markup in
// the output is markup generated below. Links/images must be http(s).
const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");

const safeUrl = (u: string) => (/^https?:\/\/[^\s]+$/i.test(u) ? u : null);

// Matches content containing no further opening [tag], so nesting resolves innermost-first.
const inner = (t: string) => `((?:(?!\\[${t}[\\]=])[\\s\\S])*?)`;

export function renderBBCode(input: string): string {
  const codes: string[] = [];
  let s = esc(input.replace(/\u0000/g, "")).replace(/\[code\]([\s\S]*?)\[\/code\]/gi, (_m, c: string) => {
    codes.push(`<pre><code>${c.replace(/^\n/, "")}</code></pre>`);
    return `\u0000${codes.length - 1}\u0000`;
  });

  const loop = (re: RegExp, fn: (...m: string[]) => string) => {
    let prev: string;
    do {
      prev = s;
      s = s.replace(re, fn as never);
    } while (s !== prev);
  };

  for (const [t, h] of [["b", "strong"], ["i", "em"], ["u", "u"], ["s", "s"]] as const) {
    loop(new RegExp(`\\[${t}\\]${inner(t)}\\[\\/${t}\\]`, "gi"), (_m, c) => `<${h}>${c}</${h}>`);
  }
  loop(new RegExp(`\\[quote(?:=([^\\]\\n]{1,40}))?\\]${inner("quote")}\\[\\/quote\\]`, "gi"), (_m, who, c) =>
    `<blockquote>${who ? `<cite>${who}</cite>` : ""}${c}</blockquote>`);
  loop(new RegExp(`\\[spoiler\\]${inner("spoiler")}\\[\\/spoiler\\]`, "gi"), (_m, c) =>
    `<details class="spoiler"><summary>Spoiler</summary>${c}</details>`);

  s = s.replace(/\[url=([^\]\s]+)\]([\s\S]*?)\[\/url\]/gi, (m, u, text) => {
    const x = safeUrl(u);
    return x ? `<a href="${x}" rel="nofollow ugc noopener" target="_blank">${text}</a>` : m;
  });
  s = s.replace(/\[url\](\S+?)\[\/url\]/gi, (m, u) => {
    const x = safeUrl(u);
    return x ? `<a href="${x}" rel="nofollow ugc noopener" target="_blank">${x}</a>` : m;
  });
  s = s.replace(/\[img\](\S+?)\[\/img\]/gi, (m, u) => {
    const x = safeUrl(u);
    return x ? `<img src="${x}" alt="" loading="lazy" referrerpolicy="no-referrer">` : m;
  });
  s = s.replace(/\[list\]([\s\S]*?)\[\/list\]/gi, (_m, body: string) => {
    const items = body.split(/\[\*\]/).slice(1).map((i) => `<li>${i.trim()}</li>`).join("");
    return `<ul>${items}</ul>`;
  });

  s = s.replace(/\n/g, "<br>");
  return s.replace(/\u0000(\d+)\u0000/g, (_m, i) => codes[Number(i)] ?? "");
}
