// Server-rendered HTML for search engines and link previews. Always rendered as a Guest,
// so it can never expose tags that guests may not view. The React app replaces it on load.
import { visibleSql } from "./perm";

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const iso = (ms: number) => new Date(ms).toISOString();
const plain = (bb: string, n = 160) => bb.replace(/\[\/?[a-z*]+(?:=[^\]]*)?\]/gi, " ").replace(/\s+/g, " ").trim().slice(0, n);

export type Page = {
  status: number; title: string; desc: string; canonical: string; body: string;
  jsonld?: unknown; noindex?: boolean;
};

export function shell(template: string, p: Page): string {
  const head = [
    `<title>${esc(p.title)}</title>`,
    `<meta name="description" content="${esc(p.desc)}">`,
    `<link rel="canonical" href="${esc(p.canonical)}">`,
    `<meta property="og:title" content="${esc(p.title)}">`,
    `<meta property="og:description" content="${esc(p.desc)}">`,
    `<meta property="og:url" content="${esc(p.canonical)}">`,
    p.noindex ? `<meta name="robots" content="noindex">` : "",
    p.jsonld ? `<script type="application/ld+json">${JSON.stringify(p.jsonld).replace(/</g, "\\u003c")}</script>` : "",
  ].join("\n    ");
  // function replacers: post text may contain "$&" and similar, which string replacers would interpret
  return template
    .replace(/<title>[\s\S]*?<\/title>/, () => head)
    .replace('<div id="root"></div>', () => `<div id="root">${p.body}</div>`);
}

type Tag = { id: number; name: string; slug: string };

export async function ssrList(db: D1Database, tagSlug: string | undefined, site: string, origin: string): Promise<Page> {
  const vt = visibleSql(null, "t.id");
  const tags = (await db.prepare(`SELECT t.id, t.name, t.slug FROM tags t WHERE ${vt.sql} ORDER BY t.position`).bind(...vt.binds).all()).results as Tag[];
  const tag = tagSlug ? tags.find((t) => t.slug === tagSlug) : undefined;
  if (tagSlug && !tag) {
    return { status: 404, title: `Not found – ${site}`, desc: "Tag not found.", canonical: origin + "/", noindex: true, body: `<main><h1>Tag not found</h1><p><a href="/">Back to all discussions</a></p></main>` };
  }
  const vd = visibleSql(null, "d.tag_id");
  const where = [vd.sql]; const binds: (string | number)[] = [...vd.binds];
  if (tag) { where.push("d.tag_id = ?"); binds.push(tag.id); }
  const rows = (await db.prepare(
    `SELECT d.id, d.title, d.post_count, d.last_post_at, u.username AS author
     FROM discussions d JOIN users u ON u.id = d.user_id WHERE ${where.join(" AND ")}
     ORDER BY d.pinned DESC, d.last_post_at DESC LIMIT 50`).bind(...binds).all()).results as any[];
  const nav = tags.map((t) => `<a href="/t/${esc(t.slug)}">${esc(t.name)}</a>`).join(" ");
  const items = rows.map((d) =>
    `<li><a href="/d/${d.id}">${esc(d.title)}</a> <small>by ${esc(d.author)}, ${d.post_count} posts, last active <time datetime="${iso(d.last_post_at)}">${iso(d.last_post_at).slice(0, 10)}</time></small></li>`).join("");
  const name = tag ? `${tag.name} – ${site}` : site;
  return {
    status: 200, title: name, canonical: origin + (tag ? `/t/${tag.slug}` : "/"),
    desc: tag ? `Discussions tagged ${tag.name} on ${site}.` : `Latest discussions on ${site}.`,
    body: `<main><h1>${esc(name)}</h1><nav>${nav}</nav><ul>${items}</ul></main>`,
  };
}

export async function ssrThread(db: D1Database, id: number, site: string, origin: string): Promise<Page> {
  const v = visibleSql(null, "d.tag_id");
  const d = (await db.prepare(
    `SELECT d.id, d.title, t.name AS tag_name, t.slug AS tag_slug FROM discussions d JOIN tags t ON t.id = d.tag_id
     WHERE d.id = ? AND ${v.sql}`).bind(id, ...v.binds).first()) as { id: number; title: string; tag_name: string; tag_slug: string } | null;
  if (!d) {
    return { status: 404, title: `Not found – ${site}`, desc: "Discussion not found.", canonical: origin + "/", noindex: true, body: `<main><h1>Discussion not found</h1><p><a href="/">Back to all discussions</a></p></main>` };
  }
  const posts = (await db.prepare(
    `SELECT p.html, p.content, p.created_at, u.username AS author FROM posts p JOIN users u ON u.id = p.user_id
     WHERE p.discussion_id = ? ORDER BY p.id LIMIT 200`).bind(id).all()).results as any[];
  const canonical = `${origin}/d/${d.id}`;
  const first = posts[0];
  const body = `<main><nav><a href="/">${esc(site)}</a> / <a href="/t/${esc(d.tag_slug)}">${esc(d.tag_name)}</a></nav><h1>${esc(d.title)}</h1>` +
    posts.map((p) => `<article><header><strong>${esc(p.author)}</strong> <time datetime="${iso(p.created_at)}">${iso(p.created_at).slice(0, 10)}</time></header><div>${p.html}</div></article>`).join("") +
    `</main>`;
  return {
    status: 200, title: `${d.title} – ${site}`, canonical, body,
    desc: first ? plain(first.content) : d.title,
    jsonld: first && {
      "@context": "https://schema.org", "@type": "DiscussionForumPosting", headline: d.title, url: canonical,
      author: { "@type": "Person", name: first.author }, datePublished: iso(first.created_at),
      text: plain(first.content, 500), commentCount: posts.length - 1,
    },
  };
}

export async function sitemapXml(db: D1Database, origin: string): Promise<string> {
  const vt = visibleSql(null, "t.id");
  const tags = (await db.prepare(`SELECT t.slug FROM tags t WHERE ${vt.sql}`).bind(...vt.binds).all()).results as any[];
  const vd = visibleSql(null, "d.tag_id");
  const rows = (await db.prepare(`SELECT d.id, d.last_post_at FROM discussions d WHERE ${vd.sql} ORDER BY d.id DESC LIMIT 5000`).bind(...vd.binds).all()).results as any[];
  const urls = [
    `<url><loc>${origin}/</loc></url>`,
    ...tags.map((t) => `<url><loc>${origin}/t/${esc(t.slug)}</loc></url>`),
    ...rows.map((d) => `<url><loc>${origin}/d/${d.id}</loc><lastmod>${iso(d.last_post_at)}</lastmod></url>`),
  ];
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.join("")}</urlset>`;
}

export const robotsTxt = (origin: string) =>
  `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /admin\n\nSitemap: ${origin}/sitemap.xml\n`;
