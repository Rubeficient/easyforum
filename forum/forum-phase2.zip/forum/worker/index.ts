import { Hono, type Context } from "hono";
import { deleteCookie, getCookie, setCookie } from "hono/cookie";
import { renderBBCode } from "./bbcode";
import { ADMIN, MEMBER, GUEST, can, isAdmin, isStaff, visibleSql, type AppEnv, type User } from "./perm";
import { robotsTxt, shell, sitemapXml, ssrList, ssrThread, type Page } from "./ssr";

const SESSION_MS = 30 * 24 * 3600 * 1000;

// ---- password hashing: PBKDF2-SHA256 (Workers caps PBKDF2 at 100k iterations)
const b64 = (b: Uint8Array) => btoa(String.fromCharCode(...b));
const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function derive(password: string, salt: Uint8Array) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations: 100_000 }, key, 256));
}
async function hashPassword(password: string) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return `${b64(salt)}:${b64(await derive(password, salt))}`;
}
async function verifyPassword(password: string, stored: string) {
  const [s, h] = stored.split(":");
  const a = await derive(password, unb64(s));
  const b = unb64(h);
  let diff = a.length ^ b.length;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ (b[i] ?? 0);
  return diff === 0;
}

type C = Context<AppEnv>;
const app = new Hono<AppEnv>();

app.use("/api/*", async (c, next) => {
  const sid = getCookie(c, "sid");
  let user: User | null = null;
  if (sid) {
    user = await c.env.DB.prepare(
      "SELECT u.id, u.username, u.group_id FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ? AND s.expires_at > ?",
    ).bind(sid, Date.now()).first<User>();
  }
  c.set("user", user);
  await next();
});

async function startSession(c: C, userId: number) {
  const sid = crypto.randomUUID() + crypto.randomUUID();
  await c.env.DB.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)").bind(sid, userId, Date.now() + SESSION_MS).run();
  setCookie(c, "sid", sid, { httpOnly: true, secure: true, sameSite: "Lax", path: "/", maxAge: SESSION_MS / 1000 });
}

/** Fixed-window limiter keyed by client IP. Returns true when the caller is over the limit. */
async function limited(c: C, name: string, max: number, windowMs: number) {
  const key = `${name}:${c.req.header("cf-connecting-ip") ?? "local"}`;
  const now = Date.now();
  const row = await c.env.DB.prepare("SELECT window_start, count FROM rate_limits WHERE key = ?").bind(key).first<{ window_start: number; count: number }>();
  if (!row || now - row.window_start > windowMs) {
    await c.env.DB.prepare("INSERT OR REPLACE INTO rate_limits (key, window_start, count) VALUES (?, ?, 1)").bind(key, now).run();
    return false;
  }
  if (row.count >= max) return true;
  await c.env.DB.prepare("UPDATE rate_limits SET count = count + 1 WHERE key = ?").bind(key).run();
  return false;
}
const tooMany = (c: C) => c.json({ error: "Too many attempts. Wait a few minutes and try again." }, 429);

// ---- auth
app.post("/api/register", async (c) => {
  if (await limited(c, "register", 5, 3600_000)) return tooMany(c);
  const { username, email, password } = await c.req.json<Record<string, string>>();
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username ?? "")) return c.json({ error: "Username must be 3–20 letters, numbers or underscores." }, 400);
  if (!/^\S+@\S+\.\S+$/.test(email ?? "")) return c.json({ error: "Enter a valid email address." }, 400);
  if ((password ?? "").length < 8) return c.json({ error: "Password must be at least 8 characters." }, 400);
  const taken = await c.env.DB.prepare("SELECT 1 FROM users WHERE username = ? OR email = ?").bind(username, email).first();
  if (taken) return c.json({ error: "That username or email is already registered." }, 409);
  const count = await c.env.DB.prepare("SELECT COUNT(*) n FROM users").first<{ n: number }>();
  const group = count?.n === 0 ? ADMIN : MEMBER; // first account becomes admin
  const res = await c.env.DB.prepare("INSERT INTO users (username, email, password_hash, group_id, created_at) VALUES (?, ?, ?, ?, ?)")
    .bind(username, email, await hashPassword(password), group, Date.now()).run();
  await startSession(c, res.meta.last_row_id);
  return c.json({ id: res.meta.last_row_id, username, group_id: group });
});

app.post("/api/login", async (c) => {
  if (await limited(c, "login", 10, 15 * 60_000)) return tooMany(c);
  const { username, password } = await c.req.json<Record<string, string>>();
  const row = await c.env.DB.prepare("SELECT id, username, group_id, password_hash FROM users WHERE username = ?")
    .bind(username ?? "").first<User & { password_hash: string }>();
  if (!row || !(await verifyPassword(password ?? "", row.password_hash))) return c.json({ error: "Username or password is incorrect." }, 401);
  await startSession(c, row.id);
  return c.json({ id: row.id, username: row.username, group_id: row.group_id });
});

app.post("/api/logout", async (c) => {
  const sid = getCookie(c, "sid");
  if (sid) await c.env.DB.prepare("DELETE FROM sessions WHERE id = ?").bind(sid).run();
  deleteCookie(c, "sid", { path: "/" });
  return c.json({ ok: true });
});

app.get("/api/me", (c) => c.json(c.get("user")));

// ---- reference data (tags are filtered to what this user may view)
app.get("/api/tags", async (c) => {
  const user = c.get("user");
  const v = visibleSql(user, "t.id");
  const tags = (await c.env.DB.prepare(`SELECT t.id, t.name, t.slug, t.color FROM tags t WHERE ${v.sql} ORDER BY t.position`).bind(...v.binds).all()).results as any[];
  const startable = new Set(
    isStaff(user) ? tags.map((t) => t.id)
      : user ? ((await c.env.DB.prepare("SELECT tag_id FROM tag_permissions WHERE group_id = ? AND permission = 'start'").bind(user.group_id).all()).results as any[]).map((r) => r.tag_id)
      : [],
  );
  return c.json(tags.map((t) => ({ ...t, can_start: startable.has(t.id) })));
});
app.get("/api/reaction-types", async (c) =>
  c.json((await c.env.DB.prepare("SELECT id, key, emoji, label FROM reaction_types ORDER BY id").all()).results));

// ---- discussions
app.get("/api/discussions", async (c) => {
  const v = visibleSql(c.get("user"), "d.tag_id");
  const where = [v.sql]; const binds: (string | number)[] = [...v.binds];
  const tag = c.req.query("tag");
  if (tag) { where.push("t.slug = ?"); binds.push(tag); }
  const rows = await c.env.DB.prepare(
    `SELECT d.id, d.title, d.pinned, d.locked, d.post_count, d.last_post_at, d.created_at,
        u.username AS author, t.name AS tag_name, t.color AS tag_color, t.slug AS tag_slug
     FROM discussions d JOIN users u ON u.id = d.user_id JOIN tags t ON t.id = d.tag_id
     WHERE ${where.join(" AND ")} ORDER BY d.pinned DESC, d.last_post_at DESC LIMIT 50`).bind(...binds).all();
  return c.json(rows.results);
});

app.post("/api/discussions", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Log in to start a discussion." }, 401);
  const { title, tagId, content } = await c.req.json<{ title: string; tagId: number; content: string }>();
  if (!title || title.trim().length < 3 || title.length > 120) return c.json({ error: "Title must be 3–120 characters." }, 400);
  if (!content?.trim() || content.length > 20000) return c.json({ error: "Write something before posting (max 20,000 characters)." }, 400);
  const tag = await c.env.DB.prepare("SELECT id FROM tags WHERE id = ?").bind(tagId).first();
  if (!tag) return c.json({ error: "Choose a tag." }, 400);
  if (!(await can(c.env.DB, user, tagId, "start"))) return c.json({ error: "You can't start discussions in that tag." }, 403);
  const now = Date.now();
  const d = await c.env.DB.prepare("INSERT INTO discussions (title, tag_id, user_id, post_count, created_at, last_post_at) VALUES (?, ?, ?, 1, ?, ?)")
    .bind(title.trim(), tagId, user.id, now, now).run();
  const id = d.meta.last_row_id;
  await c.env.DB.prepare("INSERT INTO posts (discussion_id, user_id, content, html, created_at) VALUES (?, ?, ?, ?, ?)")
    .bind(id, user.id, content, renderBBCode(content), now).run();
  return c.json({ id });
});

app.get("/api/discussions/:id", async (c) => {
  const id = Number(c.req.param("id"));
  const user = c.get("user");
  const v = visibleSql(user, "d.tag_id");
  // not-viewable looks identical to not-found, so private tags don't leak their contents
  const d = await c.env.DB.prepare(
    `SELECT d.id, d.title, d.pinned, d.locked, d.tag_id, t.name AS tag_name, t.color AS tag_color
     FROM discussions d JOIN tags t ON t.id = d.tag_id WHERE d.id = ? AND ${v.sql}`).bind(id, ...v.binds).first<any>();
  if (!d) return c.json({ error: "Discussion not found." }, 404);
  const posts = (await c.env.DB.prepare(
    `SELECT p.id, p.html, p.content, p.created_at, p.edited_at, p.user_id, u.username AS author
     FROM posts p JOIN users u ON u.id = p.user_id WHERE p.discussion_id = ? ORDER BY p.id LIMIT 200`).bind(id).all()).results as any[];
  const counts = (await c.env.DB.prepare(
    `SELECT post_id, reaction_id, COUNT(*) AS n FROM post_reactions
     WHERE post_id IN (SELECT id FROM posts WHERE discussion_id = ?) GROUP BY post_id, reaction_id`).bind(id).all()).results as any[];
  const mine = user
    ? ((await c.env.DB.prepare(
        `SELECT post_id, reaction_id FROM post_reactions WHERE user_id = ? AND post_id IN (SELECT id FROM posts WHERE discussion_id = ?)`)
        .bind(user.id, id).all()).results as any[])
    : [];
  const canReply = isStaff(user) || (!!user && !d.locked && (await can(c.env.DB, user, d.tag_id, "reply")));
  const { tag_id: _t, ...discussion } = d;
  return c.json({
    discussion, can_reply: canReply,
    posts: posts.map((p) => ({
      ...p,
      reactions: counts.filter((r) => r.post_id === p.id).map((r) => ({ reaction_id: r.reaction_id, n: r.n })),
      my_reaction: mine.find((r) => r.post_id === p.id)?.reaction_id ?? null,
    })),
  });
});

app.patch("/api/discussions/:id", async (c) => {
  if (!isStaff(c.get("user"))) return c.json({ error: "Moderators only." }, 403);
  const { pinned, locked } = await c.req.json<{ pinned?: boolean; locked?: boolean }>();
  const id = Number(c.req.param("id"));
  if (pinned !== undefined) await c.env.DB.prepare("UPDATE discussions SET pinned = ? WHERE id = ?").bind(pinned ? 1 : 0, id).run();
  if (locked !== undefined) await c.env.DB.prepare("UPDATE discussions SET locked = ? WHERE id = ?").bind(locked ? 1 : 0, id).run();
  return c.json({ ok: true });
});

// ---- posts
app.post("/api/discussions/:id/posts", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Log in to reply." }, 401);
  const id = Number(c.req.param("id"));
  const { content } = await c.req.json<{ content: string }>();
  if (!content?.trim() || content.length > 20000) return c.json({ error: "Write something before posting (max 20,000 characters)." }, 400);
  const d = await c.env.DB.prepare("SELECT locked, tag_id FROM discussions WHERE id = ?").bind(id).first<{ locked: number; tag_id: number }>();
  if (!d || !(await can(c.env.DB, user, d.tag_id, "view"))) return c.json({ error: "Discussion not found." }, 404);
  if (d.locked && !isStaff(user)) return c.json({ error: "This discussion is locked." }, 403);
  if (!(await can(c.env.DB, user, d.tag_id, "reply"))) return c.json({ error: "You can't reply in this tag." }, 403);
  const now = Date.now();
  await c.env.DB.batch([
    c.env.DB.prepare("INSERT INTO posts (discussion_id, user_id, content, html, created_at) VALUES (?, ?, ?, ?, ?)").bind(id, user.id, content, renderBBCode(content), now),
    c.env.DB.prepare("UPDATE discussions SET post_count = post_count + 1, last_post_at = ? WHERE id = ?").bind(now, id),
  ]);
  return c.json({ ok: true });
});

const postInfo = (c: C, id: number) =>
  c.env.DB.prepare("SELECT p.user_id, p.content, d.tag_id FROM posts p JOIN discussions d ON d.id = p.discussion_id WHERE p.id = ?")
    .bind(id).first<{ user_id: number; content: string; tag_id: number }>();

app.put("/api/posts/:id", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Log in to edit." }, 401);
  const id = Number(c.req.param("id"));
  const { content } = await c.req.json<{ content: string }>();
  if (!content?.trim() || content.length > 20000) return c.json({ error: "Write something before saving." }, 400);
  const post = await postInfo(c, id);
  if (!post || !(await can(c.env.DB, user, post.tag_id, "view"))) return c.json({ error: "Post not found." }, 404);
  if (post.user_id !== user.id && !isStaff(user)) return c.json({ error: "You can only edit your own posts." }, 403);
  const now = Date.now();
  await c.env.DB.batch([
    c.env.DB.prepare("INSERT INTO post_revisions (post_id, content, edited_by, created_at) VALUES (?, ?, ?, ?)").bind(id, post.content, user.id, now),
    c.env.DB.prepare("UPDATE posts SET content = ?, html = ?, edited_at = ? WHERE id = ?").bind(content, renderBBCode(content), now, id),
  ]);
  return c.json({ ok: true });
});

app.get("/api/posts/:id/revisions", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Log in to see edit history." }, 401);
  const id = Number(c.req.param("id"));
  const post = await postInfo(c, id);
  if (!post || !(await can(c.env.DB, user, post.tag_id, "view"))) return c.json({ error: "Post not found." }, 404);
  if (post.user_id !== user.id && !isStaff(user)) return c.json({ error: "Only the author and moderators can see edit history." }, 403);
  const rows = await c.env.DB.prepare(
    "SELECT r.id, r.content, r.created_at, u.username AS editor FROM post_revisions r JOIN users u ON u.id = r.edited_by WHERE r.post_id = ? ORDER BY r.id DESC").bind(id).all();
  return c.json(rows.results);
});

// one reaction per user per post; sending the same one again removes it
app.post("/api/posts/:id/react", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Log in to react." }, 401);
  const postId = Number(c.req.param("id"));
  const { reactionId } = await c.req.json<{ reactionId: number }>();
  const post = await postInfo(c, postId);
  if (!post || !(await can(c.env.DB, user, post.tag_id, "view"))) return c.json({ error: "Post not found." }, 404);
  const type = await c.env.DB.prepare("SELECT id FROM reaction_types WHERE id = ?").bind(reactionId).first();
  if (!type) return c.json({ error: "Unknown reaction." }, 400);
  const existing = await c.env.DB.prepare("SELECT reaction_id FROM post_reactions WHERE post_id = ? AND user_id = ?").bind(postId, user.id).first<{ reaction_id: number }>();
  if (existing?.reaction_id === reactionId) {
    await c.env.DB.prepare("DELETE FROM post_reactions WHERE post_id = ? AND user_id = ?").bind(postId, user.id).run();
  } else {
    await c.env.DB.prepare("INSERT OR REPLACE INTO post_reactions (post_id, user_id, reaction_id) VALUES (?, ?, ?)").bind(postId, user.id, reactionId).run();
  }
  return c.json({ ok: true });
});

// ---- admin: tags and their permissions
const ALLOWED: Record<number, string[]> = { [MEMBER]: ["view", "start", "reply"], [GUEST]: ["view"] };
const slugify = (s: string) => s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "tag";
const okColor = (s: unknown): s is string => typeof s === "string" && /^#[0-9a-f]{6}$/i.test(s);

app.use("/api/admin/*", async (c, next) => {
  if (!isAdmin(c.get("user"))) return c.json({ error: "Admins only." }, 403);
  await next();
});

app.get("/api/admin/tags", async (c) => {
  const tags = (await c.env.DB.prepare("SELECT id, name, slug, color FROM tags ORDER BY position").all()).results as any[];
  const perms = (await c.env.DB.prepare("SELECT tag_id, group_id, permission FROM tag_permissions").all()).results as any[];
  return c.json(tags.map((t) => ({
    ...t,
    perms: Object.fromEntries([MEMBER, GUEST].map((g) => [g, perms.filter((p) => p.tag_id === t.id && p.group_id === g).map((p) => p.permission)])),
  })));
});

app.post("/api/admin/tags", async (c) => {
  const { name, color } = await c.req.json<{ name: string; color: string }>();
  if (!name?.trim() || name.length > 30) return c.json({ error: "Tag name must be 1–30 characters." }, 400);
  if (!okColor(color)) return c.json({ error: "Pick a color." }, 400);
  let slug = slugify(name);
  for (let i = 2; await c.env.DB.prepare("SELECT 1 FROM tags WHERE slug = ?").bind(slug).first(); i++) slug = `${slugify(name).slice(0, 26)}-${i}`;
  const pos = (await c.env.DB.prepare("SELECT COALESCE(MAX(position), -1) + 1 AS p FROM tags").first<{ p: number }>())!.p;
  const res = await c.env.DB.prepare("INSERT INTO tags (name, slug, color, position) VALUES (?, ?, ?, ?)").bind(name.trim(), slug, color, pos).run();
  const id = res.meta.last_row_id;
  await c.env.DB.batch([
    ...["view", "start", "reply"].map((p) => c.env.DB.prepare("INSERT INTO tag_permissions (tag_id, group_id, permission) VALUES (?, ?, ?)").bind(id, MEMBER, p)),
    c.env.DB.prepare("INSERT INTO tag_permissions (tag_id, group_id, permission) VALUES (?, ?, 'view')").bind(id, GUEST),
  ]);
  return c.json({ id });
});

app.put("/api/admin/tags/:id", async (c) => {
  const id = Number(c.req.param("id"));
  const { name, color, perms } = await c.req.json<{ name: string; color: string; perms: Record<string, string[]> }>();
  if (!name?.trim() || name.length > 30) return c.json({ error: "Tag name must be 1–30 characters." }, 400);
  if (!okColor(color)) return c.json({ error: "Pick a color." }, 400);
  if (!(await c.env.DB.prepare("SELECT 1 FROM tags WHERE id = ?").bind(id).first())) return c.json({ error: "Tag not found." }, 404);
  const rows: [number, string][] = [];
  for (const g of [MEMBER, GUEST]) {
    const want = (perms?.[g] ?? []).filter((p) => ALLOWED[g].includes(p));
    if (!want.includes("view")) continue; // start/reply are meaningless without view
    for (const p of new Set(want)) rows.push([g, p]);
  }
  await c.env.DB.batch([
    c.env.DB.prepare("UPDATE tags SET name = ?, color = ? WHERE id = ?").bind(name.trim(), color, id),
    c.env.DB.prepare("DELETE FROM tag_permissions WHERE tag_id = ?").bind(id),
    ...rows.map(([g, p]) => c.env.DB.prepare("INSERT INTO tag_permissions (tag_id, group_id, permission) VALUES (?, ?, ?)").bind(id, g, p)),
  ]);
  return c.json({ ok: true });
});

// ---- server-rendered pages for crawlers and link previews (the React app takes over in browsers)
async function serve(c: C, build: (site: string, origin: string) => Promise<Page>) {
  const origin = new URL(c.req.url).origin;
  const page = await build(c.env.SITE_NAME ?? "Forum", origin);
  const tpl = await (await c.env.ASSETS.fetch(new URL("/", c.req.url))).text();
  return c.html(shell(tpl, page), page.status as 200 | 404);
}
app.get("/", (c) => serve(c, (s, o) => ssrList(c.env.DB, undefined, s, o)));
app.get("/t/:slug", (c) => serve(c, (s, o) => ssrList(c.env.DB, c.req.param("slug"), s, o)));
app.get("/d/:id", (c) => serve(c, (s, o) => ssrThread(c.env.DB, Number(c.req.param("id")) || 0, s, o)));
app.get("/sitemap.xml", async (c) => c.body(await sitemapXml(c.env.DB, new URL(c.req.url).origin), 200, { "content-type": "application/xml" }));
app.get("/robots.txt", (c) => c.text(robotsTxt(new URL(c.req.url).origin)));

export default app;
