CREATE TABLE groups (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
INSERT INTO groups (id, name) VALUES (1, 'Admin'), (2, 'Moderator'), (3, 'Member');

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  group_id INTEGER NOT NULL DEFAULT 3 REFERENCES groups(id),
  created_at INTEGER NOT NULL
);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);

CREATE TABLE tags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  color TEXT NOT NULL DEFAULT '#2f6f8f',
  parent_id INTEGER REFERENCES tags(id),
  position INTEGER NOT NULL DEFAULT 0
);
INSERT INTO tags (name, slug, color, position) VALUES
  ('General', 'general', '#2f6f8f', 0),
  ('Help', 'help', '#b4572f', 1),
  ('Showcase', 'showcase', '#5a7d3a', 2);

CREATE TABLE discussions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  tag_id INTEGER NOT NULL REFERENCES tags(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  pinned INTEGER NOT NULL DEFAULT 0,
  locked INTEGER NOT NULL DEFAULT 0,
  post_count INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  last_post_at INTEGER NOT NULL
);
CREATE INDEX idx_discussions_tag ON discussions(tag_id, last_post_at);

CREATE TABLE posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discussion_id INTEGER NOT NULL REFERENCES discussions(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  content TEXT NOT NULL,
  html TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  edited_at INTEGER
);
CREATE INDEX idx_posts_discussion ON posts(discussion_id, id);

CREATE TABLE post_revisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  edited_by INTEGER NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL
);

CREATE TABLE reaction_types (
  id INTEGER PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  emoji TEXT NOT NULL,
  label TEXT NOT NULL
);
INSERT INTO reaction_types (id, key, emoji, label) VALUES
  (1, 'like', '👍', 'Like'), (2, 'love', '❤️', 'Love'), (3, 'laugh', '😂', 'Haha'),
  (4, 'wow', '😮', 'Wow'), (5, 'sad', '😢', 'Sad'), (6, 'thanks', '🙏', 'Thanks');

CREATE TABLE post_reactions (
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reaction_id INTEGER NOT NULL REFERENCES reaction_types(id),
  PRIMARY KEY (post_id, user_id)
);
