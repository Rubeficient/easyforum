-- Guests are a virtual group (id 4): not logged in.
INSERT INTO groups (id, name) VALUES (4, 'Guest');

-- Admins and Moderators always have every permission; this table governs Members (3) and Guests (4).
CREATE TABLE tag_permissions (
  tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  group_id INTEGER NOT NULL REFERENCES groups(id),
  permission TEXT NOT NULL CHECK (permission IN ('view', 'start', 'reply')),
  PRIMARY KEY (tag_id, group_id, permission)
);
INSERT INTO tag_permissions (tag_id, group_id, permission)
  SELECT t.id, 3, p.perm FROM tags t
  CROSS JOIN (SELECT 'view' AS perm UNION ALL SELECT 'start' UNION ALL SELECT 'reply') p;
INSERT INTO tag_permissions (tag_id, group_id, permission) SELECT id, 4, 'view' FROM tags;

CREATE TABLE rate_limits (
  key TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL
);
